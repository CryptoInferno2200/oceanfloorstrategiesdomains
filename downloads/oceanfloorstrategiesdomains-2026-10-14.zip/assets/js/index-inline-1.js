location.replace("home.html");
